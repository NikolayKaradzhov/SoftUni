﻿using System;

namespace p09.CustomLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}