﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericArrayCreator
{
    class ArrayCreator
    {
    }
}
