﻿using System;

namespace p07.CustomLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}