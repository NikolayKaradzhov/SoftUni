﻿namespace Logger.Models.Contracts.Enumerations
{
    public enum Level
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}