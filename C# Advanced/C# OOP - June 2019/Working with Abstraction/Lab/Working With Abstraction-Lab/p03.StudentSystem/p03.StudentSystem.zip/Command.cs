﻿using System;
using System.Collections.Generic;
using System.Text;

namespace p03.StudentSystem
{
    public class Command
    {
        public string Name { get; set; }

        public string[] Arguments { get; set; }
    }
}