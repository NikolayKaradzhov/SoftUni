﻿namespace p04.HotelReservation
{
    public enum DiscountType
    {
        VIP = 20,
        SecondVisit = 10,
        None = 0
    }
}