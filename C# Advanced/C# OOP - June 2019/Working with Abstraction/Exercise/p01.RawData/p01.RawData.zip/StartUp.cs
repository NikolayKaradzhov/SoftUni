﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace p01.RawData
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Runner engine = new Runner();
            
            engine.Run();
        }
    }
}