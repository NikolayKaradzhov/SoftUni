﻿namespace p02.CarsSalesman
{
    public class StartUp
    {
        public static void Main()
        {
            Runner runner = new Runner();

            runner.Run();
        }
    }
}