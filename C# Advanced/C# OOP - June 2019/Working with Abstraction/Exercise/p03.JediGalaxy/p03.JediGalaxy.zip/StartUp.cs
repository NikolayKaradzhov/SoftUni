﻿using System;
using System.Linq;
using p03.JediGalaxy;

namespace p03.JediGalaxy
{
    public class StartUp
    {
        public static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}