﻿namespace MortalEngines.Core
{
    using Contracts;

    public class MachinesManager : IMachinesManager
    {
        public string HirePilot(string name)
        {
            throw new System.NotImplementedException();
        }

        public string ManufactureTank(string name, double attackPoints, double defensePoints)
        {
            throw new System.NotImplementedException();
        }

        public string ManufactureFighter(string name, double attackPoints, double defensePoints)
        {
            throw new System.NotImplementedException();
        }

        public string EngageMachine(string selectedPilotName, string selectedMachineName)
        {
            throw new System.NotImplementedException();
        }

        public string AttackMachines(string attackingMachineName, string defendingMachineName)
        {
            throw new System.NotImplementedException();
        }

        public string PilotReport(string pilotReporting)
        {
            throw new System.NotImplementedException();
        }

        public string MachineReport(string machineName)
        {
            throw new System.NotImplementedException();
        }

        public string ToggleFighterAggressiveMode(string fighterName)
        {
            throw new System.NotImplementedException();
        }

        public string ToggleTankDefenseMode(string tankName)
        {
            throw new System.NotImplementedException();
        }
    }
}