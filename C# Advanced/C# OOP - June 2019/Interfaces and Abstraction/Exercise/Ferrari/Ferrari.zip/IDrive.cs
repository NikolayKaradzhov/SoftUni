﻿namespace Ferrari
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public interface IDrive
    {
        string Brakes();

        string Gas();
    }
}