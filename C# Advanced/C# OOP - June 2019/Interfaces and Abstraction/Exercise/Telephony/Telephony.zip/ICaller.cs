﻿namespace Telephony
{
    public interface ICaller
    {
        string CallNumbers();
    }
}