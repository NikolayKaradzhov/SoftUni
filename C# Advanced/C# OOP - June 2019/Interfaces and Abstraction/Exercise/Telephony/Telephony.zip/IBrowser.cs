﻿namespace Telephony
{
    public interface IBrowser
    {
        string BrowseSites();
    }
}