﻿namespace Farm
{
    public class StartUp
    {
        public static void Main()
        {
            Dog bart = new Dog();

            bart.Bark();
            bart.Eat();
        }
    }
}