using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 3; i <= 100; i+=3)
            {
                Console.WriteLine(i);
            }
        }
    }
}
