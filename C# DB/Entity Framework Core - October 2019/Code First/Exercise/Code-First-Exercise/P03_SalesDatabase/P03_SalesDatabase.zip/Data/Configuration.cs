﻿namespace P03_SalesDatabase.Data
{
    internal static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=SalesDatabase;Integrated Security=true;";
    }
}