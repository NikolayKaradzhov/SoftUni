﻿namespace _02.Villian_Names
{
    public class DbConfig
    {
        public const string ConnectionString = @"Server=BGL063;Database=MinionsDB;Integrated Security=true";
    }
}