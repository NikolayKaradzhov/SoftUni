﻿namespace _07.PrintAllMinionNames
{
    public class Queries
    {
        public const string MinionNamesQuery = "SELECT Name FROM Minions";
    }
}