﻿namespace P03_FootballBetting
{
    public class StartUp
    {
        static void Main()
        {
            
        }
    }
}