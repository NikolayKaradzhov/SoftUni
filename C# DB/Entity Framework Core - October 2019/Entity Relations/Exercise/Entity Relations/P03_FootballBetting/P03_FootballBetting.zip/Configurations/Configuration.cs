﻿namespace P03_FootballBetting.Configurations
{
    public class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=FootballBettingDatabase;Integrated Security=true;";
    }
}