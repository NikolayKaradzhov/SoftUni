﻿namespace P01_StudentSystem
{
    public class StartUp
    {
        public static void Main()
        {
            
        }
    }
}