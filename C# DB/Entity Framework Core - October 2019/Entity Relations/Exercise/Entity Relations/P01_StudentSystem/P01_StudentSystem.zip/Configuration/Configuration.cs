﻿namespace P01_StudentSystem.Configuration
{
    public class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=StudentSystemDatabase;Integrated Security=true;";
    }
}